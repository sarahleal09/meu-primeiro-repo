<h2>Este é o repositório do projeto Grape-Sci destinado a coisas de nosso Site Institucional, e documentação de nosso projeto</h2>

<p>Aqui poderemos encontrar nosso Site Instituciional, que é feito utilizando as linguagens:</p>


![Github Badge](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![Github Badge](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![Github Badge](https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E)

<p>Em nosso site poderemos encontrar mais sobre nosso projeto, como uma tela nos falando mais sobre nós, membros da Grape-Sci, e outra tela que pode te dizer o quanto você tem a ganhar usando nosso projeto, 
  e porque ele fará a difença em seu negócio</p>

