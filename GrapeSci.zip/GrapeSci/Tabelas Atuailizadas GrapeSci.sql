create database GrapeSci;

use GrapeSci;

create table Funcionario (
idFuncionario INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(45),
cpf CHAR(11),
senha VARCHAR(45),
email VARCHAR(80),
telefone CHAR(11),
cargo VARCHAR(45),
fkEmpresa INT
);

drop table funcionario;

-- Inserindo um funcionário
INSERT INTO Funcionario (nome, cpf, senha, email, telefone, cargo, fkEmpresa) 
VALUES ('João Silva', '12345678901', 'senha123', 'joao@email.com', '1234567890', 'Analista de Vendas', 1);

-- Selecionando todos os funcionários
SELECT * FROM Funcionario;

-- Atualizando o cargo de um funcionário para 'Gerente de Vendas'
UPDATE Funcionario
SET cargo = 'Gerente de Vendas'
WHERE idFuncionario = 1;

-- JOIN entre Funcionario e Empresa usando a chave estrangeira fkEmpresa
SELECT *
FROM Funcionario AS f
JOIN Empresa AS e ON f.fkEmpresa = e.idEmpresa;

create table Empresa (
idEmpresa INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(80),
cep CHAR(8),
cnpj CHAR(14),
codAutentic INT 
);

-- Inserindo uma empresa
INSERT INTO Empresa (nome, cep, cnpj, codAutentic) 
VALUES ('Empresa A', '12345678', '12345678901234', 9876);

-- Selecionando todas as empresas
SELECT * FROM Empresa;

-- Atualizando o código de autenticação de uma empresa para 12345
UPDATE Empresa
SET codAutentic = 12345
WHERE idEmpresa = 1;


create table Estufa (
idEstufa INT PRIMARY KEY AUTO_INCREMENT,
bloco VARCHAR(45),
fkEmpresa int
);

-- Inserindo uma estufa
INSERT INTO Estufa (bloco, fkEmpresa) 
VALUES ('Bloco A', 1);

-- Selecionando todas as estufas
SELECT * FROM Estufa;

-- Atualizando o bloco de uma estufa para 'Bloco B'
UPDATE Estufa
SET bloco = 'Bloco B'
WHERE idEstufa = 1;

-- JOIN entre Estufa e Empresa usando a chave estrangeira fkEmpresa
SELECT *
FROM Estufa AS est
JOIN Empresa AS e ON est.fkEmpresa = e.idEmpresa;

create table Uva (
idUva INT PRIMARY KEY AUTO_INCREMENT,
nomeTipo VARCHAR(45),
fkplantacao INT
);

-- Inserindo uma uva
INSERT INTO Uva (nomeTipo, fkplantacao) 
VALUES ('Uva A', 1);

-- Selecionando todas as uvas
SELECT * FROM Uva;

-- Atualizando o nome de uma variedade de uva para 'Uva B'
UPDATE Uva
SET nomeTipo = 'Uva B'
WHERE idUva = 1;

-- JOIN entre Uva e Plantacao usando a chave estrangeira fkplantacao
SELECT *
FROM Uva AS u
JOIN Plantacao AS p ON u.fkplantacao = p.idCadastroUva;


create table Metrica (
idMetrica INT PRIMARY KEY AUTO_INCREMENT,
tempIdeal DOUBLE,
umiIdeal DOUBLE,
FKUva INT 
);

-- Inserindo uma métrica
INSERT INTO Metrica (tempIdeal, umiIdeal, FKUva) 
VALUES (25.0, 60.0, 1);

-- Selecionando todas as métricas
SELECT * FROM Metrica;

-- Atualizando a temperatura ideal em uma métrica para 28.0
UPDATE Metrica
SET tempIdeal = 28.0
WHERE idMetrica = 1;

-- JOIN entre Metrica e Uva usando a chave estrangeira FKUva
SELECT *
FROM Metrica AS m
JOIN Uva AS u ON m.FKUva = u.idUva;

create table Plantacao (
idCadastroUva INT PRIMARY KEY AUTO_INCREMENT,
qtdVieiras INT,
qtdAreaPlant DOUBLE,
fkEstufa INT 
);

-- Inserindo uma plantação
INSERT INTO Plantacao (qtdVieiras, qtdAreaPlant, fkEstufa) 
VALUES (100, 50.0, 1);

-- Selecionando todas as plantações
SELECT * FROM Plantacao;

-- Atualizando a quantidade de vieiras em uma plantação para 120
UPDATE Plantacao
SET qtdVieiras = 120
WHERE idCadastroUva = 1;

-- JOIN entre Plantacao e Estufa usando a chave estrangeira fkEstufa
SELECT *
FROM Plantacao AS p
JOIN Estufa AS est ON p.fkEstufa = est.idEstufa;

create table Dispositivo (
idDispositivo INT PRIMARY KEY AUTO_INCREMENT,
fkPlantacao INT
);

-- Inserindo um dispositivo
INSERT INTO Dispositivo (fkPlantacao) 
VALUES (1);

-- Selecionando todos os dispositivos
SELECT * FROM Dispositivo;

-- JOIN entre Dispositivo e Plantacao usando a chave estrangeira fkPlantacao
SELECT *
FROM Dispositivo AS d
JOIN Plantacao AS p ON d.fkPlantacao = p.idCadastroUva;


create table Registro (
consultaUmi DOUBLE,
consultaTemp DOUBLE,
registroDt DATETIME,
fkDispositivo INT
);

-- Inserindo um registro
INSERT INTO Registro (consultaUmi, consultaTemp, registroDt, fkDispositivo) 
VALUES (65.0, 26.0, NOW(), 1);

-- Selecionando todos os registros
SELECT * FROM Registro;

-- JOIN entre Registro e Dispositivo usando a chave estrangeira fkDispositivo
SELECT *
FROM Registro AS r
JOIN Dispositivo AS d ON r.fkDispositivo = d.idDispositivo;
